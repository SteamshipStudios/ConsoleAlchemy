#Intro
sinsterslackerstudios = input('Steamship Studios presents...')                                                                      
consolealchemy = input('Console Alchemy!')                                                                        
start = input('Press any button to start!')
#Gives the player a list of basic elements to make it easier for them to play.
print('Here is a list of elements you can combine!')
print('     air')
print('     earth')
print('     fire')
print('     water')
print('Your inputted element must be inputted in lowercase.')



name = input('\nWhat is your name?')

def combo():
    #Asks the player what elements they want to combine, this is essential to gameplay, do not modify.
    element1 = input(f'\nWell {name.title()}, what is the first element you want to combine?')
    element2 = input('And what is the second element you want to combine?')

    #The recipes for elements, which makes the above section actually mean something.
    if element1 == 'water':
        if element2 == 'water':
            print(f'Woah {name.title()}! You made the sea!')
            print('The little brother of the ocean!')
    
    if element1 == 'sea':
        if element2 == 'sea':
            print(f'Woah {name.title()}! You made the ocean!')
            print('The bigger brother of the sea!')
    
    if element1 == 'fire':
        if element2 == 'fire':
            print(f'Woah {name.title()}! You made energy!')
            print('E=mc squared!')
    
    if element1 == 'energy':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made electricity!')
            print('An electrifying discovery!')

    if element1 == 'electricity':
        if element2 == 'sea':
            print(f'Woah {name.title()}! You made primordial soup!')
            print('Sure does not taste like soup though.')
    
    if element1 == 'primordial soup':
        if element2 == 'energy':
            print(f'Woah {name.title()}! You made life!')
            print('The more lively brother of death!')
    
    if element1 == 'life':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made animals!')
            print('Just like animals, animals.')
    
    if element1 == 'fire':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made smoke!')
            print('Smoke weed everyday...')
    
    if element1 == 'fire':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made lava!')
            print('Mongoose, Guava juice.')
    
    if element1 == 'animal':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made fossils!')
            print('What do you call a fossil that lies around all day? Lazy bones!')
    
    if element1 == 'air':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made pressure!')
            print('Fear of missing out!')
    
    if element1 == 'earth':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made dirt!')
            print('Very dirty!')
            
def changelog():
    print('Version 0.02: Made game playable and added more elements, also removed cool ASCII due to it not display correctly.')
    print('Version 0.01: Overhauled game.')

    

def credit():
    print('All of the code: Cohen Scheffrin')
    print('Some combination ideas: Richard Scheffrin')


def mainmenu():
    print('What would you like to do?')
    print('Play')
    print('Credits')
    print('Changelog')
    optionalism = input('Choose! 1, 2 or 3?')

    if optionalism == '1':
        combo()
    if optionalism == '2':
        credit()
    if optionalism == '3':
        changelog()

mainmenu()

byebye = input('Quit? YES or NO')
if byebye == 'NO':
    mainmenu()
else:
    print('')

