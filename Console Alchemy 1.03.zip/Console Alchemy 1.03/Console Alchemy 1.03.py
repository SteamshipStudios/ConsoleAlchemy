import random 
#Intro
sinsterslackerstudios = input('Steamship Studios presents...')                                                                      
consolealchemy = input('Console Alchemy!')                                                                        
start = input('Press any button to start!')
#Gives the player a list of basic elements to make it easier for them to play.
print('Here is a list of elements you can combine!')
print('     air')
print('     earth')
print('     fire')
print('     water')
print('     sin')
print('     virtue')

print('Your inputted element must be inputted in lowercase.')


randomseed = {random.randint(1,2)}
name = input('\nWhat is your name?')

def combo():
    
    censorship = input('If you want no censorship, say 1. If you want censorship, say 2.')
    element1 = input(f'\nWell {name.title()}, what is the first element you want to combine?')
    element2 = input('And what is the second element you want to combine?')

    #The recipes for elements, which makes the above section actually mean something.
    if element1 == 'water':
        if element2 == 'water':
            print(f'Woah {name.title()}! You made the sea!')
            print('The little brother of the ocean!')
    
    if element1 == 'sea':
        if element2 == 'sea':
            print(f'Woah {name.title()}! You made the ocean!')
            print('The bigger brother of the sea!')
    
    if element1 == 'fire':
        if element2 == 'fire':
            print(f'Woah {name.title()}! You made energy!')
            print('E=mc squared!')
    
    if element1 == 'energy':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made electricity!')
            print('An electrifying discovery!')

    if element1 == 'electricity':
        if element2 == 'sea':
            print(f'Woah {name.title()}! You made primordial soup!')
            print('Sure does not taste like soup though.')
    
    if element1 == 'primordial soup':
        if element2 == 'energy':
            print(f'Woah {name.title()}! You made life!')
            print('The more lively brother of death!')
    
    if element1 == 'life':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made animals!')
            print('Just like animals, animals.')
    
    if element1 == 'fire':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made smoke!')
            if censorship == '1':
                print('Smoke weed everyday...')
            else:
                print('Smoke rhymes with cloak!')
    
    if element1 == 'fire':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made lava!')
            print('Mongoose, Guava juice.')
    
    if element1 == 'animal':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made fossils!')
            print('What do you call a fossil that lies around all day? Lazy bones!')
    
    if element1 == 'air':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made pressure!')
            print('Fear of missing out!')
    
    if element1 == 'earth':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made dirt!')
            print('Very dirty!')
    
    if element1 == 'air':
        if element2 == 'pressure':
            print(f'Woah {name.title()}! You made heat!')
            print('No, I am not making that joke!')
    
    if element1 == 'water':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made mist!')
            print('I tried to hit it, but I mist!')
    
    if element1 == 'fossil':
        if element2 == 'life':
            print(f'Woah {name.title()}! You made dinosaurs!')
            print('The origin of rawr?')
    
    if element1 == 'fossil':
        if element2 == 'fire':
            print(f'Woah {name.title()}! You made fossil fuels!')
            print('Cough, cough.')
    
    if element1 == 'fossil fuel':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made carbon!')
            print('Who decided to introduce the perodic table to this game?!')
    
    if element1 == 'dirt':
        if element2 == 'dirt':
            print(f'Woah {name.title()}! You made bricks!')
            print('Brick Brock.')
    
    if element1 == 'brick':
        if element2 == 'brick':
            print(f'Woah {name.title()}! You made walls!')
            print('For wallhalla!')
    
    if element1 == 'wall':
        if element2 == 'wall':
            print(f'Woah {name.title()}! You made houses!')
            print('Home sweet home is where the heart is!')
    
    if element1 == 'house':
        if element2 == 'fossil fuels':
            print(f'Woah {name.title()}! You made industry!')
            print('In my dust tray!')
            
    if element1 == 'house':
        if element2 == 'house':
            print(f'Woah {name.title()}! You made neighbourhoods')
            print('Only in the USA!')
    
    if element1 == 'neighbourhood':
        if element2 == 'neighbourhood':
            print(f'Woah {name.title()}! You made cities!')
            if randomseed == 1:
                print('Its a tale of two cities!')
            else:
                print('Its a tale of two kitties!')
    
    if element1 == 'city':
        if element2 == 'city':
            print(f'Woah {name.title()}! You made countries!')
            print('The rice of the count!')
    
    if element1 == 'country':
        if element2 == 'country':
            print(f'Woah {name.title()}! You made continents!')
            print('English is my favorite continent!')
    
    if element1 == 'continent':
        if element2 == 'continent':
            print(f'Woah {name.title()}! You made planets!')
            print('Planet X!')
    
    if element1 == 'planet':
        if element2 == 'fire':
            print(f'Woah {name.title()}! You made stars!')
            print('Wish upon a star!')
    
    if element1 == 'star':
        if element2 == 'star':
            print(f'Woah {name.title()}! You made suns!')
            print('Brrrr?')
    
    if element1 == 'carbon':
        if element2 == 'water':
            print(f'Woah {name.title()}! You made oxygen!')
            print('Breathe in, breath out!')
    
    if element1 == 'carbon':
        if element2 == 'oxygen':
            print(f'Woah {name.title()}! You made carbon dioxide!')
            print('Cough, cough, wheeze.')
    
    if element1 == 'planet':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made atmosphere!')
            print('I can finally breathe!')
    
    if element1 == 'atmosphere':
        if element2 == 'planet':
            print(f'Woah {name.title()}! You made gas planets!')
            print('Gas, gas, gas!')
    
    if element1 == 'atmosphere':
        if element2 == 'carbon dioxide':
            print(f'Woah {name.title()}! You made global warming!')
            print('Now you can make politics! Just kidding.')
    
    if element1 == 'industry':
        if element2 == 'industry':
            print(f'Woah {name.title()}! You made companies!')
            print('In these uncertain times...')
    
    if element1 == 'company':
        if element2 == 'company':
            print(f'Woah {name.title()}! You made money!')
            print('Money, how I love thee!')
    

    if element1 == 'money':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made greed!')
            print('Hello, valued customer, would you like to purchase some Nestle Crunch?')

    
    if element1 == 'animal':
        if element2 == 'animal':
            print(f'Woah {name.title()}! You made humans!')
            print('Lets get retarded!')
    
    if element1 == 'human':
        if element2 == 'human':
            print(f'Woah {name.title()}! You made love!')
            print('Love makes the world go round!')
    

    if element1 == 'love':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made lust!')
            print('Trust dust!')
    
    if element1 == 'dirt':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made stone!')
            print('Sticks and stones make break your bones...')
    
    if element1 == 'stone':
        if element2 == 'stone':
            print(f'Woah {name.title()}! You made metal!')
            print('Granite is my favorite genre of music.')
    
    if element1 == 'metal':
        if element2 == 'metal':
            print(f'Woah {name.title()}! You made steel!')
            print('Its worst enemy is steeless stains!')
    
    if element1 == 'money':
        if element2 == 'human':
            print(f'Woah {name.title()}! You made the upper-class!')
            print('INSERT UNIRONIC COMMUNISM')
    

    if element1 == 'upper-class':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made envy!')
            print('Yellow with envy!')
    
    if element1 == 'animal':
        if element2 == 'human':
            print(f'Woah {name.title()}! You made food!')
            print('Yummy!')
    

    if element1 == 'food':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made gluttony!')
            print('I have no comment.')
    
    if element1 == 'animal':
        if element2 == 'stone':
            print(f'Woah {name.title()}! You made sloths!')
            print('Uhhh...')
    

    if element1 == 'sloth':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made laziness!')
            print('A La-Z Boy chair!')
    
    if element1 == 'stone':
        if element2 == 'air':
            print(f'Woah {name.title()}! You made erosion!')
            print('The erosion diet!')
    
    if element1 == 'stone':
        if element2 == 'erosion':
            print(f'Woah {name.title()}! You made nothing!')
            print('404: Description not found.')
    
    if element1 == 'nothing':
        if element2 == 'nothing':
            print(f'Woah {name.title()}! You made no!')
            print('No!')
    
    if element1 == 'no':
        if element2 == 'no':
            print(f'Woah {name.title()}! You made not!')
            print('This is not is!')
    
    if element1 == 'love':
        if element2 == 'not':
            print(f'Woah {name.title()}! You made hate!')
            print('If hate was engraved on every microangstrem of my motherboard...')
     
    

    if element1 == 'hate':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made wrath!')
            print('Gir-wrath!')
    
    if element1 == 'no':
        if element2 == 'nothing':
            print(f'Woah {name.title()}! You made everything!')
            print('Everything is now 80% off on Steam!')
    
    if element1 == 'everything':
        if element2 == 'nothing':
            print(f'Woah {name.title()}! You made self!')
            print('I have no comment.')
    
    if element1 == 'self':
        if element2 == 'love':
            print(f'Woah {name.title()}! You made ego!')
    

    if element1 == 'ego':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made pride!')
            print('I have no comment.') 
    
    if element1 == 'sin':
        if element2 == 'sin':
            print(f'Woah {name.title()}! You made evil!')
            print('Every villain is lemons!')
    
    if element1 == 'virtue':
        if element2 == 'virtue':
            print(f'Woah {name.title()}! You made good!')
            print('Good.')
    
    if element1 == 'good':
        if element2 == 'good':
            print(f'Woah {name.title()}! You made christ!')
            print('Imma murder you with a pencil.')
    
    if element1 == 'evil':
        if element2 == 'evil':
            print(f'Woah {name.title()}! You made antichrist!')
            print('Bye-bye to your vision!')
        
    if element1 == 'christ':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made heaven!')
            print('Stairway to heaven!')
    
    if element1 == 'antichrist':
        if element2 == 'earth':
            print(f'Woah {name.title()}! You made hell!')
            print('Highway to hell!')
    
    if element1 == 'heaven':
        if element2 == 'hell':
            print(f'Woah {name.title()}! You made afterlife!')
            print('Highstair to afterlife!')
    
    if element1 == 'afterlife':
        if element2 == 'human':
            print(f'Woah {name.title()}! You made soul!')
            print('Ghoul does not rhyme with soul?')
            
    if element1 == 'idea':
        if element2 == 'afterlife':
            print(f'Woah {name.title()}! You made religion!')
            print('Hey chat, I just got this invite to a cult, should I join it?')
            if censorship == '1':
                sleep(1)
                print('Oops chat, its a sex suicide cult! Im not really into that!')
            if censorship == '2':
                print('')
    
    if element1 == 'religion':
        if element2 == 'no':
            print(f'Woah {name.title()}! You made atheism!')
            print('A default subreddit!')

    if element1 == 'atheism':
        if element2 == 'atheism':
            print(f'Woah {name.title()}! You made reddit!')
            print('Yeah, I reddit!')
            
    if element1 == 'reddit':
        if element2 == 'reddit':
            print(f'Woah {name.title()}! You made twitter!')
            print('Console+alchemy+ratio')

    if element1 == 'twitter':
        if element2 == 'twitter':
            print(f'Woah {name.title()}! You made 4Chan!')
            print('Welcome to hell!')

    if element1 == '4chan':
        if element2 == '4chan':
            print(f'Woah {name.title()}! You made Tor!')
            print('Oh god no!')

    if element1 == 'tor':
        if element2 == 'tor':
            print(f'Woah {name.title()}! You made chrome!')
            print('Uh oh!')
    
    if element1 == 'steel':
        if element2 == 'human':
            print(f'Woah {name.title()}! You made a robot!')
            print('Beep bop!')

    if element1 == 'twitter':
        if element2 == 'robot':
            print(f'Woah {name.title()}! You made a graphic designer!')
            print('In USD only!')
    
    if element1 == 'graphic designer':
        if element2 == 'human':
            print(f'Woah {name.title()}! You made an oxymoron!')
            print('Happy monday!')

    if element1 == 'steel':
        if element2 == 'food':
            print(f'Woah {name.title()}! You made a steel meal!')
            print('My teeth!')
    
    if element1 == 'human':
        if element2 == 'food':
            print(f'Woah {name.title()}! You made cannibalism!')
            print('Ewwwww!')
            
def changelog():
    print('Version 1.02: Added censorship and more religious elements, and also some elements that are less than religious.')
    print('Version 1.01: Added virtues, added good and evil! Changed the description of Upper-class element!')
    print('Version 1.00: Added more sins! Added technological elements!')
    print('Version 0.04: Added sin element!')
    print('Version 0.03: Added plenty combinations! And carbon and oxygen for the turbo-nerds, in other words: me')
    print('Version 0.02: Made game playable and added more elements, also removed cool ASCII due to it not display correctly.')
    print('Version 0.01: Overhauled game.')

    

def credit():
    print('All of the code: Cohen Scheffrin')
    print('Some combination ideas: Richard Scheffrin')

def contact():
    print('Contact us at: cohenpirate@gmail.com!')
    print('Bugs reports and suggestions? Just contact us!')


def mainmenu():
    print('What would you like to do?')
    print('Play')
    print('Credits')
    print('Changelog')
    print('Contact')
    optionalism = input('Choose! 1, 2, 3 or 4?')

    if optionalism == '1':
        combo()
    if optionalism == '2':
        credit()
    if optionalism == '3':
        changelog()
    if optionalism == '4':
        contact()

mainmenu()

byebye = input('Quit? Y = YES, N = NO')
if byebye == 'N':
    mainmenu()
else:
    print('')

